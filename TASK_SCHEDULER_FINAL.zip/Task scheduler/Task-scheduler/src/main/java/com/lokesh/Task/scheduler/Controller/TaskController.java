package com.lokesh.Task.scheduler.Controller;

import com.lokesh.Task.scheduler.Model.Task;
import com.lokesh.Task.scheduler.Service.TaskService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/tasks")
@CrossOrigin(origins = "*")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @PostMapping
    public Task createTask(@RequestBody Task task) {
        return taskService.addTaskWithUndo(task);
    }

    @GetMapping
    public List<Task> getAllTasks() {
        return taskService.getAllNonCompletedTasks();
    }


    @GetMapping("/sorted/priority")
    public List<Task> getTasksSortedByPriority() {
        return taskService.getTasksSortedByPriority();
    }

    @PostMapping("/undo")
    public String undoLast() {
        return taskService.undoLastTask();
    }

    @PostMapping("/redo")
    public String redoLast() {
        return taskService.redoLastUndo();
    }

    @GetMapping("/search")
    public ResponseEntity<?> searchByTitle(@RequestParam String title) {
        Task found = taskService.searchTaskByTitle(title);
        if (found != null) {
            return ResponseEntity.ok(found);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Task not found");
        }
    }

    @GetMapping("/top")
    public List<Task> getTopKTasks(@RequestParam int k) {
        return taskService.getTopKPriorityTasks(k);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteTask(@PathVariable Long id) {
        return taskService.deleteTaskById(id);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Task> updateTask(@PathVariable Long id, @RequestBody Task task) {
        return taskService.updateTask(id, task);
    }
    @PutMapping("/{id}/complete")
    public ResponseEntity<String> completeTask(@PathVariable Long id) {
        return taskService.completeTask(id);
    }

    @GetMapping("/completed")
    public List<Task> getCompletedTasks() {
        return taskService.getCompletedTasks();
    }



}
