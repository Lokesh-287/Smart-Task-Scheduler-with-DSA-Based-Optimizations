package com.lokesh.Task.scheduler.Repository;

import com.lokesh.Task.scheduler.Model.Task;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskRepository extends JpaRepository<Task, Long> {
}
