package com.lokesh.Task.scheduler.Service;

import com.lokesh.Task.scheduler.Model.Task;
import com.lokesh.Task.scheduler.Repository.TaskRepository;
import com.lokesh.Task.scheduler.dsa.TaskActionStack;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TaskService {

    private final TaskRepository taskRepo;

    public TaskService(TaskRepository taskRepo) {
        this.taskRepo = taskRepo;
    }

    public Task addTask(Task task) {
        return taskRepo.save(task);
    }


    public List<Task> getAllNonCompletedTasks() {
        List<Task> allTasks = taskRepo.findAll();
        List<Task> result = new ArrayList<>();

        for (Task task : allTasks) {
            if (!"Completed".equalsIgnoreCase(task.getStatus())) {
                result.add(task);
            }
        }

        // Sort by priority (descending)
        result.sort((a, b) -> b.getPriority() - a.getPriority());

        return result;
    }




    public List<Task> getTasksSortedByPriority() {
        List<Task> tasks = taskRepo.findAll();
        // Add sorting logic here if needed
        return tasks;
    }

    public Task addTaskWithUndo(Task task) {
        Task saved = taskRepo.save(task);
        TaskActionStack.pushToUndo(saved);
        TaskActionStack.clearRedo();  // Reset redo stack after new action
        return saved;
    }

    public String undoLastTask() {
        Task last = TaskActionStack.undo();
        if (last != null) {
            taskRepo.deleteById(last.getId());
            return "Undo successful for Task: " + last.getTitle();
        }
        return "No task to undo.";
    }

    public String redoLastUndo() {
        Task redoTask = TaskActionStack.redo();
        if (redoTask != null) {
            taskRepo.save(redoTask);
            return "Redo successful for Task: " + redoTask.getTitle();
        }
        return "No task to redo.";
    }


    public Task searchTaskByTitle(String title) {
        List<Task> allTasks = taskRepo.findAll();

        for (Task task : allTasks) {
            if (task.getTitle().equalsIgnoreCase(title)) {
                return task;
            }
        }

        return null; // Not found
    }


    public List<Task> getTopKPriorityTasks(int k) {
        List<Task> allTasks = taskRepo.findAll();

        // Sort tasks by priority descending
        allTasks.sort((a, b) -> b.getPriority() - a.getPriority());

        List<Task> topK = new ArrayList<>();
        for (int i = 0; i < k && i < allTasks.size(); i++) {
            topK.add(allTasks.get(i));
        }

        return topK;
    }


    public ResponseEntity<String> deleteTaskById(Long id) {
        if (taskRepo.existsById(id)) {
            taskRepo.deleteById(id);
            return ResponseEntity.ok("Task deleted successfully");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Task not found");
        }
    }

    public ResponseEntity<Task> updateTask(Long id, Task updatedTask) {
        if (taskRepo.existsById(id)) {
            updatedTask.setId(id);  // Ensure the ID is the same as the original task's ID
            Task savedTask = taskRepo.save(updatedTask);
            return ResponseEntity.ok(savedTask);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    public ResponseEntity<String> completeTask(Long id) {
        if (taskRepo.existsById(id)) {
            Task task = taskRepo.findById(id).get();

            // Mark task as completed
            task.setStatus("Completed");

            // Save the task with updated status
            taskRepo.save(task);

            return ResponseEntity.ok("Task marked as completed.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Task not found.");
        }
    }

    public List<Task> getCompletedTasks() {
        List<Task> allTasks = taskRepo.findAll();
        List<Task> completed = new ArrayList<>();

        for (Task task : allTasks) {
            if ("Completed".equalsIgnoreCase(task.getStatus())) {
                completed.add(task);
            }
        }

        // Optional: sort by creation time or priority
        completed.sort((a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt()));

        return completed;
    }





}
