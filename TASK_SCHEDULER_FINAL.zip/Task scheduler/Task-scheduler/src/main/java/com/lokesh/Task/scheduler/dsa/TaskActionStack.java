package com.lokesh.Task.scheduler.dsa;

import com.lokesh.Task.scheduler.Model.Task;

import java.util.Stack;

public class TaskActionStack {

    public static Stack<Task> undoStack = new Stack<>();
    public static Stack<Task> redoStack = new Stack<>();

    public static void pushToUndo(Task task) {
        undoStack.push(task);
    }

    public static void pushToRedo(Task task) {
        redoStack.push(task);
    }

    public static Task undo() {
        if (!undoStack.isEmpty()) {
            Task lastAction = undoStack.pop();
            redoStack.push(lastAction);
            return lastAction;
        }
        return null;
    }

    public static Task redo() {
        if (!redoStack.isEmpty()) {
            Task task = redoStack.pop();
            undoStack.push(task);
            return task;
        }
        return null;
    }

    public static void clearRedo() {
        redoStack.clear();
    }
}
