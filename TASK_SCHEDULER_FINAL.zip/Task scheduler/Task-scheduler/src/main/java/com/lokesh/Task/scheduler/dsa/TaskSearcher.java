package com.lokesh.Task.scheduler.dsa;



import com.lokesh.Task.scheduler.Model.Task;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TaskSearcher {

    // Sorts and performs binary search by title
    public static Task binarySearchByTitle(List<Task> tasks, String targetTitle) {
        // Sort tasks alphabetically by title
        Collections.sort(tasks, Comparator.comparing(Task::getTitle));

        int low = 0;
        int high = tasks.size() - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            Task midTask = tasks.get(mid);
            int cmp = midTask.getTitle().compareToIgnoreCase(targetTitle);

            if (cmp == 0) {
                return midTask;
            } else if (cmp < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return null; // Not found
    }
}
