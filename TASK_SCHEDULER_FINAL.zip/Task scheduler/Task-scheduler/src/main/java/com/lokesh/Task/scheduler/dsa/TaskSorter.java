package com.lokesh.Task.scheduler.dsa;


import com.lokesh.Task.scheduler.Model.Task;

import java.util.List;

public class TaskSorter {

    // Sort tasks by priority (QuickSort)
    public static void quickSortByPriority(List<Task> tasks, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(tasks, low, high);
            quickSortByPriority(tasks, low, pivotIndex - 1);
            quickSortByPriority(tasks, pivotIndex + 1, high);
        }
    }

    private static int partition(List<Task> tasks, int low, int high) {
        Task pivot = tasks.get(high);
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (tasks.get(j).getPriority() < pivot.getPriority()) {
                i++;
                swap(tasks, i, j);
            }
        }

        swap(tasks, i + 1, high);
        return i + 1;
    }

    private static void swap(List<Task> tasks, int i, int j) {
        Task temp = tasks.get(i);
        tasks.set(i, tasks.get(j));
        tasks.set(j, temp);
    }
}
