package com.lokesh.Task.scheduler.dsa;


import com.lokesh.Task.scheduler.Model.Task;

import java.util.*;

public class TopKTaskSelector {

    public static List<Task> getTopKTasks(List<Task> tasks, int k) {
        // PriorityQueue to sort tasks by priority (min-heap)
        PriorityQueue<Task> pq = new PriorityQueue<>(Comparator.comparingInt(Task::getPriority));

        for (Task task : tasks) {
            pq.offer(task);
        }

        List<Task> topK = new ArrayList<>();
        while (k-- > 0 && !pq.isEmpty()) {
            topK.add(pq.poll());
        }

        return topK;
    }
}
